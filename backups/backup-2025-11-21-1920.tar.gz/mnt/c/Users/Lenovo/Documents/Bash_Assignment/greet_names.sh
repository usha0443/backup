#!/bin/bash
# Script 3: Greet multiple names

while true
do
    echo "Enter a name (or type 'done' to stop):"
    read name
    if [ "$name" = "done" ]; then
        break
    fi
    echo "Hello, $name!"
done