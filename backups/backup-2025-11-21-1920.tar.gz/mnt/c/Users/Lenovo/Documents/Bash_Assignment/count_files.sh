#!/bin/bash
# Script 2: Count number of files

count=$(ls -1 | wc -l)
echo "Number of files in this directory: $count"