## Python Calculator
  
This is a basic calculator built in python that
performs:
-Addition
-Subtraction
-Multiplication
-Division

## How to Run
1.Open a terminal.
2.Run the file:
 '''bash
 python calculator.py